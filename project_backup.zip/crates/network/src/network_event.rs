use std::net::SocketAddr;

use crate::message::NetworkMessage;

#[derive(Debug)]
pub enum NetworkEvent {
    Message {
        peer: SocketAddr,
        message: NetworkMessage,
    },
    Disconnected {
        peer: SocketAddr,
    },
}
